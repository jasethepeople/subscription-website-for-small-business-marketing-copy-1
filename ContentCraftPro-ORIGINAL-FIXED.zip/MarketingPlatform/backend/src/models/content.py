from src.models import db
from datetime import datetime
import uuid

class ContentItem(db.Model):
    __tablename__ = 'content_items'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'), nullable=False)
    type = db.Column(db.String(50), nullable=False)  # social, email, ad
    platform = db.Column(db.String(50), nullable=True)  # facebook, instagram, twitter, etc.
    content_text = db.Column(db.Text, nullable=True)
    media_urls = db.Column(db.JSON, nullable=True)  # Array of media URLs
    status = db.Column(db.String(20), nullable=False, default='draft')  # draft, scheduled, published
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    scheduled_for = db.Column(db.DateTime, nullable=True)
    published_at = db.Column(db.DateTime, nullable=True)
    template_id = db.Column(db.String(36), db.ForeignKey('templates.id'), nullable=True)
    
    def __repr__(self):
        return f'<ContentItem {self.id}>'


class Template(db.Model):
    __tablename__ = 'templates'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    category = db.Column(db.String(50), nullable=False)  # social, email, ad
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.Text, nullable=True)
    structure_json = db.Column(db.JSON, nullable=False)  # Template structure
    thumbnail_url = db.Column(db.String(255), nullable=True)
    is_premium = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    content_items = db.relationship('ContentItem', backref='template', lazy=True)
    
    def __repr__(self):
        return f'<Template {self.name}>'
