# Database Models
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import uuid

# Create a single SQLAlchemy instance to be used throughout the application
db = SQLAlchemy()

# Import models after db is defined to avoid circular imports
def init_models():
    # These imports are placed here to avoid circular imports
    from models.user import User, BusinessProfile
    from models.subscription import Plan, Subscription
    from models.content import ContentItem, Template
    
    return {
        'User': User,
        'BusinessProfile': BusinessProfile,
        'Plan': Plan,
        'Subscription': Subscription,
        'ContentItem': ContentItem,
        'Template': Template
    }
