#!/usr/bin/env python3
"""
ContentCraft Pro - Simplified Backend for Python 3.13
A subscription-based marketing platform for small businesses
"""

import json
import os
import hashlib
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import jwt

app = Flask(__name__)
CORS(app)

# Configuration
app.config['SECRET_KEY'] = 'your-secret-key-change-in-production'
JWT_SECRET = 'jwt-secret-key-change-in-production'

# Data storage paths
DATA_DIR = 'data'
USERS_FILE = os.path.join(DATA_DIR, 'users.json')
CONTENT_FILE = os.path.join(DATA_DIR, 'content.json')
TEMPLATES_FILE = os.path.join(DATA_DIR, 'templates.json')

# Ensure data directory exists
os.makedirs(DATA_DIR, exist_ok=True)

def load_json_file(filename):
    """Load data from JSON file"""
    if os.path.exists(filename):
        try:
            with open(filename, 'r') as f:
                return json.load(f)
        except:
            return {}
    return {}

def save_json_file(filename, data):
    """Save data to JSON file"""
    with open(filename, 'w') as f:
        json.dump(data, f, indent=2)

def hash_password(password):
    """Hash password using SHA256"""
    return hashlib.sha256(password.encode()).hexdigest()

def generate_jwt_token(user_id):
    """Generate JWT token for user"""
    payload = {
        'user_id': user_id,
        'exp': datetime.utcnow() + timedelta(days=30)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm='HS256')

def verify_jwt_token(token):
    """Verify JWT token"""
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=['HS256'])
        return payload['user_id']
    except:
        return None

# Initialize default templates
def init_templates():
    """Initialize default templates"""
    templates = load_json_file(TEMPLATES_FILE)
    if not templates:
        default_templates = {
            "1": {
                "id": "1",
                "category": "social_media",
                "name": "Product Showcase",
                "description": "Highlight your products with style",
                "structure_json": {
                    "platform": "facebook",
                    "headline": "Check out our amazing [PRODUCT_NAME]!",
                    "content": "🌟 Introducing [PRODUCT_NAME] - the perfect solution for [TARGET_AUDIENCE]!\n\n✨ Key benefits:\n• [BENEFIT_1]\n• [BENEFIT_2]\n• [BENEFIT_3]\n\n💬 What do you think? Let us know in the comments!\n\n#[BUSINESS_NAME] #[PRODUCT_CATEGORY] #SmallBusiness",
                    "tags": ["product", "showcase", "business"]
                },
                "thumbnail_url": "/static/thumbnails/product_showcase.jpg",
                "is_premium": False
            },
            "2": {
                "id": "2",
                "category": "email",
                "name": "Customer Newsletter",
                "description": "Keep your customers informed",
                "structure_json": {
                    "subject": "Monthly Update from [BUSINESS_NAME]",
                    "content": "Hi [CUSTOMER_NAME],\n\nWe hope this email finds you well! Here's what's new at [BUSINESS_NAME]:\n\n📢 Latest News:\n[NEWS_ITEM_1]\n[NEWS_ITEM_2]\n\n🎯 Special Offers:\n[OFFER_DETAILS]\n\n📞 Contact us if you have any questions!\n\nBest regards,\nThe [BUSINESS_NAME] Team",
                    "tags": ["newsletter", "email", "updates"]
                },
                "thumbnail_url": "/static/thumbnails/newsletter.jpg",
                "is_premium": False
            },
            "3": {
                "id": "3",
                "category": "digital_ad",
                "name": "Special Promotion",
                "description": "Drive engagement with offers",
                "structure_json": {
                    "headline": "🔥 Limited Time Offer - [DISCOUNT]% OFF!",
                    "content": "Don't miss out on our biggest sale of the year!\n\n💰 Save [DISCOUNT]% on [PRODUCT/SERVICE]\n⏰ Offer expires [END_DATE]\n🎯 Perfect for [TARGET_AUDIENCE]\n\n👆 Click to claim your discount now!",
                    "call_to_action": "Shop Now",
                    "tags": ["promotion", "sale", "discount"]
                },
                "thumbnail_url": "/static/thumbnails/promotion.jpg",
                "is_premium": True
            }
        }
        save_json_file(TEMPLATES_FILE, default_templates)

# API Routes
@app.route('/')
def home():
    """Home route"""
    return jsonify({
        "message": "ContentCraft Pro API is running",
        "status": "success",
        "version": "1.0.0"
    })

@app.route('/api/auth/register', methods=['POST'])
def register():
    """User registration"""
    data = request.get_json()
    
    if not data or not data.get('email') or not data.get('password') or not data.get('name'):
        return jsonify({"error": "Missing required fields"}), 400
    
    users = load_json_file(USERS_FILE)
    
    # Check if user already exists
    for user_id, user in users.items():
        if user['email'] == data['email']:
            return jsonify({"error": "User already exists"}), 400
    
    # Create new user
    user_id = str(len(users) + 1)
    new_user = {
        "id": user_id,
        "name": data['name'],
        "email": data['email'],
        "password": hash_password(data['password']),
        "subscription_tier": "basic",
        "created_at": datetime.utcnow().isoformat(),
        "business_name": "",
        "industry": "",
        "website": ""
    }
    
    users[user_id] = new_user
    save_json_file(USERS_FILE, users)
    
    # Generate token
    token = generate_jwt_token(user_id)
    
    return jsonify({
        "message": "User registered successfully",
        "token": token,
        "user": {
            "id": user_id,
            "name": new_user['name'],
            "email": new_user['email'],
            "subscription_tier": new_user['subscription_tier']
        }
    })

@app.route('/api/auth/login', methods=['POST'])
def login():
    """User login"""
    data = request.get_json()
    
    if not data or not data.get('email') or not data.get('password'):
        return jsonify({"error": "Missing email or password"}), 400
    
    users = load_json_file(USERS_FILE)
    
    # Find user
    user_found = None
    for user_id, user in users.items():
        if user['email'] == data['email'] and user['password'] == hash_password(data['password']):
            user_found = (user_id, user)
            break
    
    if not user_found:
        return jsonify({"error": "Invalid credentials"}), 401
    
    user_id, user = user_found
    token = generate_jwt_token(user_id)
    
    return jsonify({
        "message": "Login successful",
        "token": token,
        "user": {
            "id": user_id,
            "name": user['name'],
            "email": user['email'],
            "subscription_tier": user['subscription_tier']
        }
    })

@app.route('/api/templates', methods=['GET'])
def get_templates():
    """Get all templates"""
    templates = load_json_file(TEMPLATES_FILE)
    return jsonify({"templates": list(templates.values())})

@app.route('/api/content', methods=['POST'])
def create_content():
    """Create new content"""
    # Get token from header
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith('Bearer '):
        return jsonify({"error": "Missing or invalid token"}), 401
    
    token = auth_header.split(' ')[1]
    user_id = verify_jwt_token(token)
    
    if not user_id:
        return jsonify({"error": "Invalid token"}), 401
    
    data = request.get_json()
    if not data:
        return jsonify({"error": "Missing content data"}), 400
    
    content_data = load_json_file(CONTENT_FILE)
    
    # Create new content
    content_id = str(len(content_data) + 1)
    new_content = {
        "id": content_id,
        "user_id": user_id,
        "type": data.get('type', 'social_media'),
        "platform": data.get('platform', 'facebook'),
        "headline": data.get('headline', ''),
        "content": data.get('content', ''),
        "tags": data.get('tags', []),
        "status": "draft",
        "created_at": datetime.utcnow().isoformat()
    }
    
    content_data[content_id] = new_content
    save_json_file(CONTENT_FILE, content_data)
    
    return jsonify({
        "message": "Content created successfully",
        "content": new_content
    })

@app.route('/api/content', methods=['GET'])
def get_user_content():
    """Get user's content"""
    # Get token from header
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith('Bearer '):
        return jsonify({"error": "Missing or invalid token"}), 401
    
    token = auth_header.split(' ')[1]
    user_id = verify_jwt_token(token)
    
    if not user_id:
        return jsonify({"error": "Invalid token"}), 401
    
    content_data = load_json_file(CONTENT_FILE)
    
    # Filter content by user
    user_content = []
    for content in content_data.values():
        if content['user_id'] == user_id:
            user_content.append(content)
    
    return jsonify({"content": user_content})

@app.route('/api/subscriptions', methods=['GET'])
def get_subscription_plans():
    """Get subscription plans"""
    plans = {
        "basic": {
            "name": "Basic",
            "price": 19.99,
            "features": [
                "20 content generations per month",
                "Basic templates",
                "Facebook and Instagram support",
                "Email support"
            ]
        },
        "professional": {
            "name": "Professional", 
            "price": 49.99,
            "features": [
                "100 content generations per month",
                "AI assistance",
                "Premium templates",
                "All social platforms",
                "Priority support"
            ]
        },
        "enterprise": {
            "name": "Enterprise",
            "price": 99.99,
            "features": [
                "Unlimited content generation",
                "Advanced AI assistance",
                "All templates",
                "All platforms including TikTok",
                "Dedicated support",
                "Custom branding"
            ]
        }
    }
    
    return jsonify({"plans": plans})

@app.route('/api/user/profile', methods=['GET'])
def get_user_profile():
    """Get user profile"""
    # Get token from header
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith('Bearer '):
        return jsonify({"error": "Missing or invalid token"}), 401
    
    token = auth_header.split(' ')[1]
    user_id = verify_jwt_token(token)
    
    if not user_id:
        return jsonify({"error": "Invalid token"}), 401
    
    users = load_json_file(USERS_FILE)
    user = users.get(user_id)
    
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Remove password from response
    user_profile = {k: v for k, v in user.items() if k != 'password'}
    
    return jsonify({"user": user_profile})

@app.route('/api/user/profile', methods=['PUT'])
def update_user_profile():
    """Update user profile"""
    # Get token from header
    auth_header = request.headers.get('Authorization')
    if not auth_header or not auth_header.startswith('Bearer '):
        return jsonify({"error": "Missing or invalid token"}), 401
    
    token = auth_header.split(' ')[1]
    user_id = verify_jwt_token(token)
    
    if not user_id:
        return jsonify({"error": "Invalid token"}), 401
    
    data = request.get_json()
    if not data:
        return jsonify({"error": "Missing update data"}), 400
    
    users = load_json_file(USERS_FILE)
    user = users.get(user_id)
    
    if not user:
        return jsonify({"error": "User not found"}), 404
    
    # Update allowed fields
    allowed_fields = ['name', 'business_name', 'industry', 'website']
    for field in allowed_fields:
        if field in data:
            user[field] = data[field]
    
    users[user_id] = user
    save_json_file(USERS_FILE, users)
    
    # Remove password from response
    user_profile = {k: v for k, v in user.items() if k != 'password'}
    
    return jsonify({
        "message": "Profile updated successfully",
        "user": user_profile
    })

# Serve static files (for frontend)
@app.route('/static/<path:filename>')
def serve_static(filename):
    """Serve static files"""
    return send_from_directory('static', filename)

if __name__ == '__main__':
    # Initialize templates on startup
    init_templates()
    
    print("🚀 ContentCraft Pro Backend Starting...")
    print("📊 Platform: Subscription-based Marketing Platform")
    print("💰 Revenue Model: $19.99, $49.99, $99.99 monthly tiers")
    print("🎯 Target: Small business marketing automation")
    print("✅ Python 3.13 Compatible!")
    print("")
    print("🌐 Backend API: http://localhost:5000")
    print("📚 API Documentation: http://localhost:5000")
    print("")
    
    app.run(host='0.0.0.0', port=5000, debug=True)

